#include "send.h"

#include "SysTick.h"
#include <stdio.h>  
#include <string.h>  
#include <stdbool.h>

#include "usart2.h"


#include "rtc.h"
#include "mod.h"
#include "string.h"
#include "sim800.h"
/************************************************
*����ͨ��wifi���䵽������
************************************************/
extern usart_st  usart_data;
extern uint64_t datanum;
uint16_t address;
char senddata[200];	 
char rx_buf_str[255];  //���������ַ�����ʽ
char body_data_1[160];        //�跢������
char body_data_2[40]; 
char body_data_3[40]; 
char body_data_len=0;
char jsondata[500];
char postdata[200];
extern t_DEV dev;
extern  struct Data_Time  timer;
extern  struct NEW_Time newtimer;
volatile uint8_t ucTcpClosedFlag = 0;


 /*�ֽ���ת�ַ���
**������  sourceԴ����
**     dest  Ŀ���ַ���
**     sourceLen����
*/
 void ByteToHexStr(const unsigned char* source, char* dest, int sourceLen)  
{  
    short i;  
    unsigned char highByte, lowByte;  
  
    for (i = 0; i < sourceLen; i++)  
    {  
        highByte = source[i] >> 4;  
        lowByte = source[i] & 0x0f ;  
  
        highByte += 0x30;  
  
        if (highByte > 0x39)  
                dest[i * 2] = highByte + 0x07;  
        else  
                dest[i * 2] = highByte;  
  
        lowByte += 0x30;  
        if (lowByte > 0x39)  
            dest[i * 2 + 1] = lowByte + 0x07;  
        else  
            dest[i * 2 + 1] = lowByte;  
    }  
    return ;  
}  




 //����ת�����ȡ
void convert()
{
	  //�ֽ���ת��
     ByteToHexStr(usart_data.rx_buf,rx_buf_str,usart_data.rx_len_ed); 
	  //�������ȡ�ĳ���
	  //body_data_len=usart_data.rx_buf[2]*2;
	  //���������ݽ�ȡ  
	  strncpy(body_data_1,rx_buf_str+6,160);  
   //strncpy(body_data_2,rx_buf_str+26,20);  
	  //strncpy(body_data_3,rx_buf_str+46,20);
}

//�������ݴ��
/* ��������packagedata()
** ����������Ҫ���͵Ĳ���ת��json
*/
void packagedata()
{
	  //Time_Get(); 
	 	address=usart_data.tx_buf[3]+40001;
  	convert();
	 int m=0;
	  m++;
	Time_Get();
//	 if(SIM800_Send_Cmd("AT+CCLK?","+CCLK:",200)==0)
//						
//						 { newtimer.newyear=(dev.usart_data[10]-'0')*10+(dev.usart_data[11]-'0')+2000;
//							 newtimer.newmonth=(dev.usart_data[13]-'0')*10+(dev.usart_data[14]-'0');
//							 newtimer.newdate=(dev.usart_data[16]-'0')*10+(dev.usart_data[17]-'0');
//							
//							 newtimer.newhour=(dev.usart_data[19]-'0')*10+(dev.usart_data[20]-'0');
//							 newtimer.newmin=(dev.usart_data[22]-'0')*10+(dev.usart_data[23]-'0');
//							 newtimer.newsec=(dev.usart_data[25]-'0')*10+(dev.usart_data[26]-'0');			 
//						 }
//	sprintf(senddata,"{\r\n address:\"%u\",\
//		\r\n data_1:\"%s\",\
//	\r\n time:\"%d.%d.%d %d:%d:%d\",\
//		\r\n}",address,body_data_1,timer.w_year,timer.w_month,timer.w_date,timer.hour,timer.min,timer.sec);

//		sprintf(senddata,"{\r\n address:\"%s\",\
//		\r\n data_1:\"%s\",\
//	\r\n time:\"%d.%02d.%02d %02d:%02d:%02d\",\
//		\r\n}","123456","hello",timer.w_year,timer.w_month,timer.w_date,timer.hour,timer.min,timer.sec);				 
		sprintf(senddata,"{\r\n address:\"%s\",\
		\r\n data_1:\"%s\",\
	\r\n ,\
		\r\n}","123456","hello");				 
		


	USART2_printf("%d��%02d��%02d��%02d��%02d��%02d��\r\n",timer.w_year,timer.w_month,timer.w_date,timer.hour,timer.min,timer.sec);		
}

//�����post����
void packagepost(char *ip,char *port,char *page)
{
    char content_page[54];
		sprintf(jsondata,"{\r\n address:\"%s\",\
		\r\n data_1:\"%s\",\
		\r\n }","12345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890","asdg");
	
    sprintf(content_page,"POST //api.heclouds.com/devices/44203742/datapoints?type=3 HTTP/1.1\r\n");
    char content_host[50];
    sprintf(content_host,"api-key:IP8B8HwCCC0wF6QJcYckQvYn9dU=\r\n");
    char content_type[] = "Content-Type:application/json-patch+json\r\n";
    char content_len[300];
    sprintf(content_len,"Content-Length: %d\r\n\r\n",strlen(jsondata));
    sprintf(postdata,"%s%s%s%s%s",content_page,content_host,content_type,content_len,senddata);
   	//sprintf(postdata,"%s",jsondata);
}

void clear()
{
memset(body_data_1,0,20);
	memset(body_data_2,0,20);
	memset(body_data_3,0,20);
}
