#ifndef  __RTC_H
#define	 __RTC_H
#include "stm32f10x.h"
struct Data_Time
{
	uint8_t hour;
	uint8_t min;
	uint8_t sec;			
	//������������
	u16 w_year;
	u8  w_month;
	u8  w_date;
	uint8_t  week;
};  

 struct NEW_Time
{
 uint8_t newhour;
	uint8_t newmin;
	uint8_t newsec;			
	//������������
	uint16_t newyear;
	u8  newmonth;
	u8  newdate;
	u8  newweek;	
};



	u8 Init_RTC(void);
u8 Is_Leap_Year(u16 year);
u8 Time_Update(u16 syear,u8 smon,u8 sday,u8 hour,u8 min,u8 sec);
u8 Time_Get(void);
u8 RTC_Get_Week(u16 year,u8 month,u8 day);
u8 Usart_Scanf(u32 value,u8 count);
void Time_Set(void);
#endif



